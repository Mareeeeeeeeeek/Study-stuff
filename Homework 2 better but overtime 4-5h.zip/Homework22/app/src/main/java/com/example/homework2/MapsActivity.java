package com.example.homework2;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements
        OnMapReadyCallback,
        GoogleMap.OnMapLoadedCallback,
        GoogleMap.OnMapClickListener,
        GoogleMap.OnMapLongClickListener,
        GoogleMap.OnMarkerClickListener,
        SensorEventListener {

    private static final int MY_PERMISSION_REQUEST_ACCESS_FINE_LOCATION = 101;
    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest mLocationRequest;
    private LocationCallback locationCallback;
    private TextView accSensorTextView;
    private FloatingActionButton oButton;
    private FloatingActionButton xButton;
    SensorManager sensorManager;
    Sensor accSensor;
    Marker gpsMarker = null;
    List<Marker> markerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        markerList = new ArrayList<>();

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        accSensorTextView = (TextView) findViewById(R.id.accSensorTextView);
        oButton = (FloatingActionButton) findViewById(R.id.oButton);
        xButton = (FloatingActionButton) findViewById(R.id.xButton);


        xButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                ObjectAnimator animateDown = ObjectAnimator.ofFloat(xButtonUse() , "translationY", 200f);
                animateDown.setDuration(0);
                ObjectAnimator animationUp = ObjectAnimator.ofFloat(xButtonUse(), "translationY", 0f);
                animationUp.setDuration(1000);
            }
        });
        oButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                ObjectAnimator animateDown = ObjectAnimator.ofFloat(oButtonUse() , "translationY", 200f);
                animateDown.setDuration(0);
                ObjectAnimator animationUp = ObjectAnimator.ofFloat(oButtonUse(), "translationY", 0f);
                animationUp.setDuration(1000);
            }
        });
    }

    protected void onPause(){
        super.onPause();
        stopLocationUpdates();
    }
    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setOnMapLoadedCallback(this);
        mMap.setOnMarkerClickListener(this);
        mMap.setOnMapLongClickListener(this);
    }

    @Override
    public void onMapLoaded() {

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSION_REQUEST_ACCESS_FINE_LOCATION);
            return;
        }

        Task<Location> lastLocation = fusedLocationClient.getLastLocation();

        lastLocation.addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null && mMap != null){
                }
            }
        });

        createLocationRequest();
        createLocationCallback();
        startLocationUpdates();
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        ObjectAnimator animateDown = ObjectAnimator.ofFloat(showxoButtons() , "translationY", 200f);
        animateDown.setDuration(0);
        ObjectAnimator animationUp = ObjectAnimator.ofFloat(showxoButtons(), "translationY", 0f);
        animationUp.setDuration(1000);

        return false;
    }
    private float showxoButtons(){
        oButton.setVisibility(View.VISIBLE);
        xButton.setVisibility(View.VISIBLE);
        return 0;
    }
    public float xButtonUse(){
        accSensorTextView.setVisibility(View.INVISIBLE);
        oButton.setVisibility(View.INVISIBLE);
        xButton.setVisibility(View.INVISIBLE);
        return 0;
    }
    public float oButtonUse(){
        accSensorTextView.setVisibility(View.VISIBLE);
        return 0;
    }

   @Override
    public void onMapClick(LatLng latLng) {
        ObjectAnimator animateDown = ObjectAnimator.ofFloat(hidexoButtons() , "translationY", 200f);
        animateDown.setDuration(0);
        ObjectAnimator animationUp = ObjectAnimator.ofFloat(hidexoButtons(), "translationY", 0f);
        animationUp.setDuration(1000);
        hidexoButtons();
    }

    private float hidexoButtons(){
        oButton.setVisibility(View.INVISIBLE);
        xButton.setVisibility(View.INVISIBLE);
        return 0;
    }

    @Override
    public void onMapLongClick(LatLng latLng) {
            Marker marker =
                    mMap.addMarker(new MarkerOptions().position(latLng)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                            .alpha(0.8f)
                            .title(String.format("Position:(%.2f, %.2f)",latLng.latitude,latLng.longitude)));
                    markerList.add(marker);
    }

    private void createLocationRequest(){
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @SuppressLint("MissingPermission")
    private void startLocationUpdates(){
        fusedLocationClient.requestLocationUpdates(mLocationRequest,locationCallback,null);
    }
    private void stopLocationUpdates(){
        if(locationCallback != null)
            fusedLocationClient.removeLocationUpdates(locationCallback);
    }
    private void createLocationCallback(){
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult){
            }

        };
    }

    public void zoomInClick(View view) {
        mMap.moveCamera(CameraUpdateFactory.zoomIn());
    }

    public void zoomOutClick(View view){
        mMap.moveCamera(CameraUpdateFactory.zoomOut());
    }

    public void clearMemoryClick(View view) {
        for(Marker marker : markerList)
            marker.remove();
        accSensorTextView.setVisibility(View.INVISIBLE);
    }
    @SuppressLint("DefaultLocale")
    private void SetInformation(SensorEvent sensorEvent) {
        String information;
        information = String.format("Acceleration:\n" +
                "X(%.4f), Y(%.4f)", sensorEvent.values[0], sensorEvent.values[1]);

        accSensorTextView.setText(information);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener((SensorEventListener) this, accSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
            SetInformation(sensorEvent);
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }
}