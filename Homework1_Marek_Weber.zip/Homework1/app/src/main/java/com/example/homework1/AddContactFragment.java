package com.example.homework1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.homework1.contact.ContactContent;

public class AddContactFragment extends Fragment {

    public AddContactFragment() {}

    public static AddContactFragment newInstance() {
        return new AddContactFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_contact, container, false);
        view.findViewById(R.id.buttonAdd).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String name = ((EditText)view.findViewById(R.id.editTextName)).getText().toString();
                String surname = ((EditText)view.findViewById(R.id.editTextSurname)).getText().toString();
                String nameAndSurname = name + " " + surname;
                String phone = ((EditText)view.findViewById(R.id.editTextPhone)).getText().toString();
                String ringtone = ((Spinner)view.findViewById(R.id.spinnerRingtone)).getSelectedItem().toString();
                String avatar = ((Spinner)view.findViewById(R.id.spinnerAvatar)).getSelectedItem().toString();

                if(name.isEmpty()) {
                    nameAndSurname = "John Smith";
                }
                if(phone.isEmpty()) {
                    phone = "123456789";
                }

                ContactContent.addItem(new ContactContent.Contact(String.valueOf(ContactContent.ITEMS.size()+1), nameAndSurname, phone, ringtone, avatar));
                NavHostFragment.findNavController(AddContactFragment.this).navigate(R.id.action_addContactFragment_to_contactFragment);
            }
        });

        view.findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavHostFragment.findNavController(AddContactFragment.this).navigate(R.id.action_addContactFragment_to_contactFragment);
            }
        });
        return view;
    }
}