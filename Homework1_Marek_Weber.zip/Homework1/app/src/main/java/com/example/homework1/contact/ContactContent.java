
package com.example.homework1.contact;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactContent {

    public static final List<Contact> ITEMS = new ArrayList<Contact>();
    public static final Map<String, Contact> ITEM_MAP = new HashMap<String, Contact>();



    public static void addItem(Contact item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    private static Contact createContact(int position) {
        return new Contact(String.valueOf(position), "Item " + position, createDetails(position));
    }

    private static String createDetails(int position) {
        return "Item details: " + position;
    }

    public static void removeItem(int currentItemPosition) {
        String id = ITEMS.get(currentItemPosition).id;
        ITEMS.remove(currentItemPosition);
        ITEM_MAP.remove(id);
    }

    public static class Contact {
        public final String id;
        public final String nameAndSurname;
        public final String phone;
        public final String ringtonePath;
        public final String imagePath;

        public Contact(String id, String nameAndSurname, String phone) {
            this.id = id;
            this.nameAndSurname = nameAndSurname;
            this.phone = phone;
            this.imagePath = "";
            this.ringtonePath = "";
        }

        public Contact(String id, String nameAndSurname, String phone, String ringtonePath, String imagePath) {
            this.id = id;
            this.nameAndSurname = nameAndSurname;
            this.phone = phone;
            this.ringtonePath = ringtonePath;
            this.imagePath = imagePath;
        }

        @Override
        public String toString() {
            return nameAndSurname;
        }
    }
}
