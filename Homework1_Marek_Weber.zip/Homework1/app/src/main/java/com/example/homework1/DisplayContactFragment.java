package com.example.homework1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.homework1.contact.ContactContent;

public class DisplayContactFragment extends Fragment {
    TextView textViewContactNameAndSurname;
    TextView textViewContactPhone;
    TextView textViewContactRingtone;
    ImageView imageViewContactAvatar;

    public DisplayContactFragment() {}

    public static DisplayContactFragment newInstance() {
        return new DisplayContactFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_display_contact, container, false);
        textViewContactNameAndSurname = view.findViewById(R.id.textViewNameAndSurname);
        textViewContactPhone = view.findViewById(R.id.textViewPhone);
        textViewContactRingtone = view.findViewById(R.id.textViewRingtone);
        imageViewContactAvatar = view.findViewById(R.id.imageViewAvatar);

        Bundle arguments = getArguments();
        if(arguments != null){
            if(arguments.containsKey(getString(R.string.contact_position_key))){
                int position = arguments.getInt(getString(R.string.contact_position_key));
                displayContact(position);
            }
        }
        return view;
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    public void displayContact (int position){
        ContactContent.Contact contact = ContactContent.ITEMS.get(position);
        textViewContactNameAndSurname.setText(contact.nameAndSurname);
        textViewContactPhone.setText(contact.phone);
        String imagePath = contact.imagePath;
        String ringtonePath = contact.ringtonePath;
        Context context = getContext();
        if(imagePath != null && !imagePath.isEmpty()) {
            Drawable drawAvatar;
            switch (imagePath){
                case "Avatar 2":
                    drawAvatar = context.getDrawable(R.drawable.avatar_2);
                    break;
                case "Avatar 3":
                    drawAvatar = context.getDrawable(R.drawable.avatar_3);
                    break;
                case "Avatar 4":
                    drawAvatar = context.getDrawable(R.drawable.avatar_4);
                    break;
                case "Avatar 5":
                    drawAvatar = context.getDrawable(R.drawable.avatar_5);
                    break;
                case "Avatar 6":
                    drawAvatar = context.getDrawable(R.drawable.avatar_6);
                    break;
                case "Avatar 7":
                    drawAvatar = context.getDrawable(R.drawable.avatar_7);
                    break;
                case "Avatar 8":
                    drawAvatar = context.getDrawable(R.drawable.avatar_8);
                    break;
                case "Avatar 9":
                    drawAvatar = context.getDrawable(R.drawable.avatar_9);
                    break;
                case "Avatar 10":
                    drawAvatar = context.getDrawable(R.drawable.avatar_10);
                    break;
                case "Avatar 11":
                    drawAvatar = context.getDrawable(R.drawable.avatar_11);
                    break;
                case "Avatar 12":
                    drawAvatar = context.getDrawable(R.drawable.avatar_12);
                    break;
                case "Avatar 13":
                    drawAvatar = context.getDrawable(R.drawable.avatar_13);
                    break;
                case "Avatar 14":
                    drawAvatar = context.getDrawable(R.drawable.avatar_14);
                    break;
                case "Avatar 15":
                    drawAvatar = context.getDrawable(R.drawable.avatar_15);
                    break;
                case "Avatar 16":
                    drawAvatar = context.getDrawable(R.drawable.avatar_16);
                    break;
                default:
                    drawAvatar = context.getDrawable(R.drawable.avatar_1);
            }
            imageViewContactAvatar.setImageDrawable(drawAvatar);
        }
        else {
            imageViewContactAvatar.setImageDrawable(context.getDrawable(R.drawable.avatar_1));
        }
        if(ringtonePath != null && !ringtonePath.isEmpty()){
            switch (ringtonePath){
                case "Boi ringtone":
                    textViewContactRingtone.setText(R.string.ringtone_1);
                    break;
                case "Dance ringtone":
                    textViewContactRingtone.setText(R.string.ringtone_2);
                    break;
                case "Wide ringtone":
                    textViewContactRingtone.setText(R.string.ringtone_3);
                    break;
                default:
                    textViewContactRingtone.setText(R.string.ringtone_1);
            }
        }
        else {
            textViewContactRingtone.setText(R.string.ringtone_1);
        }
    }
}