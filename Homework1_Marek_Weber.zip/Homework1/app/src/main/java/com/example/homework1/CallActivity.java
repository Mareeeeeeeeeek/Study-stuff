package com.example.homework1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.homework1.contact.ContactContent;

public class CallActivity extends AppCompatActivity implements View.OnClickListener {

    private MediaPlayer callSignalPlayer;

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForDrawables"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);

        Intent receivedIntent = getIntent();
        int position = receivedIntent.getIntExtra(getString(R.string.contact_position_key),0 );
        ContactContent.Contact contact = ContactContent.ITEMS.get(position);

        TextView callTextView = findViewById(R.id.textViewCall);
        callTextView.setText(getString(R.string.calling_message) + contact.nameAndSurname);

        ImageView callAvatarImageView = findViewById(R.id.imageViewCallAvatar);
        ImageButton dismissCallImageButton = findViewById(R.id.imageButtonCallCancel);
        dismissCallImageButton.setOnClickListener(this);

        String imagePath = contact.imagePath;
        String ringtonePath = contact.ringtonePath;
        Context context = getApplicationContext();

        if(imagePath != null && !imagePath.isEmpty()) {
            Drawable drawAvatar;
            switch (imagePath) {
                case "Avatar 2":
                    drawAvatar = context.getDrawable(R.drawable.avatar_2);
                    break;
                case "Avatar 3":
                    drawAvatar = context.getDrawable(R.drawable.avatar_3);
                    break;
                case "Avatar 4":
                    drawAvatar = context.getDrawable(R.drawable.avatar_4);
                    break;
                case "Avatar 5":
                    drawAvatar = context.getDrawable(R.drawable.avatar_5);
                    break;
                case "Avatar 6":
                    drawAvatar = context.getDrawable(R.drawable.avatar_6);
                    break;
                case "Avatar 7":
                    drawAvatar = context.getDrawable(R.drawable.avatar_7);
                    break;
                case "Avatar 8":
                    drawAvatar = context.getDrawable(R.drawable.avatar_8);
                    break;
                case "Avatar 9":
                    drawAvatar = context.getDrawable(R.drawable.avatar_9);
                    break;
                case "Avatar 10":
                    drawAvatar = context.getDrawable(R.drawable.avatar_10);
                    break;
                case "Avatar 11":
                    drawAvatar = context.getDrawable(R.drawable.avatar_11);
                    break;
                case "Avatar 12":
                    drawAvatar = context.getDrawable(R.drawable.avatar_12);
                    break;
                case "Avatar 13":
                    drawAvatar = context.getDrawable(R.drawable.avatar_13);
                    break;
                case "Avatar 14":
                    drawAvatar = context.getDrawable(R.drawable.avatar_14);
                    break;
                case "Avatar 15":
                    drawAvatar = context.getDrawable(R.drawable.avatar_15);
                    break;
                case "Avatar 16":
                    drawAvatar = context.getDrawable(R.drawable.avatar_16);
                    break;
                default:
                    drawAvatar = context.getDrawable(R.drawable.avatar_1);
            }
            callAvatarImageView.setImageDrawable(drawAvatar);
        }
        else {
            callAvatarImageView.setImageDrawable(context.getDrawable(R.drawable.avatar_1));
        }

        Uri[] ringtone = new Uri[3];
        ringtone[0] = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.boi_ringtone);
        ringtone[1] = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.dance_ringtone);
        ringtone[2] = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.wide_ringtone);

        if(ringtonePath != null && !ringtonePath.isEmpty()) {
            switch (ringtonePath) {
                case "Boi ringtone":
                    callSignalPlayer = MediaPlayer.create(this, ringtone[0]);
                    break;
                case "Dance ringtone":
                    callSignalPlayer = MediaPlayer.create(this, ringtone[1]);
                    break;
                case "Wide ringtone":
                default:
                    callSignalPlayer = MediaPlayer.create(this, ringtone[2]);
            }
        }
        else {
            callSignalPlayer = MediaPlayer.create(this, ringtone[0]);
        }
        callSignalPlayer.start();
        callSignalPlayer.setOnCompletionListener(mp -> callSignalPlayer.start());
    }

    @Override
    public void onPause() {
        super.onPause();
        callSignalPlayer.reset();
    }

    @Override
    public void onClick(View v) {
        callSignalPlayer.reset();
        finish();
    }
}