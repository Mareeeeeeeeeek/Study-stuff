package com.example.homework1;

import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.homework1.contact.ContactContent.Contact;

import java.util.List;

public class MyContactRecyclerViewAdapter extends RecyclerView.Adapter<MyContactRecyclerViewAdapter.ViewHolder> {

    private final List<Contact> Values;
    public interface InputEventsListener{
        void onItemClick(int position);
        void onItemLongClick(int position);
        void onItemDeleteClick(int position);
    }
    private InputEventsListener Listener;

    public void setInputEventsListener (InputEventsListener listener) {
                Listener = listener;
    }

    public MyContactRecyclerViewAdapter(List<Contact> items) {
        Values = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.finalItem = Values.get(position);
        holder.finalIdView.setText(Values.get(position).id);
        holder.finalNameSurnameView.setText(Values.get(position).nameAndSurname);
        //String soundPath = holder.mItem.soundPath;
        String imagePath = holder.finalItem.imagePath;
        Context context = holder.finalView.getContext();
        if(imagePath != null && !imagePath.isEmpty()){
            Drawable drawAvatar;
            switch (imagePath) {
                case "Avatar 2":
                    drawAvatar = context.getDrawable(R.drawable.avatar_2);
                    break;
                case "Avatar 3":
                    drawAvatar = context.getDrawable(R.drawable.avatar_3);
                    break;
                case "Avatar 4":
                    drawAvatar = context.getDrawable(R.drawable.avatar_4);
                    break;
                case "Avatar 5":
                    drawAvatar = context.getDrawable(R.drawable.avatar_5);
                    break;
                case "Avatar 6":
                    drawAvatar = context.getDrawable(R.drawable.avatar_6);
                    break;
                case "Avatar 7":
                    drawAvatar = context.getDrawable(R.drawable.avatar_7);
                    break;
                case "Avatar 8":
                    drawAvatar = context.getDrawable(R.drawable.avatar_8);
                    break;
                case "Avatar 9":
                    drawAvatar = context.getDrawable(R.drawable.avatar_9);
                    break;
                case "Avatar 10":
                    drawAvatar = context.getDrawable(R.drawable.avatar_10);
                    break;
                case "Avatar 11":
                    drawAvatar = context.getDrawable(R.drawable.avatar_11);
                    break;
                case "Avatar 12":
                    drawAvatar = context.getDrawable(R.drawable.avatar_12);
                    break;
                case "Avatar 13":
                    drawAvatar = context.getDrawable(R.drawable.avatar_13);
                    break;
                case "Avatar 14":
                    drawAvatar = context.getDrawable(R.drawable.avatar_14);
                    break;
                case "Avatar 15":
                    drawAvatar = context.getDrawable(R.drawable.avatar_15);
                    break;
                case "Avatar 16":
                    drawAvatar = context.getDrawable(R.drawable.avatar_16);
                    break;
                default:
                    drawAvatar = context.getDrawable(R.drawable.avatar_1);
            }
            holder.finalImageView.setImageDrawable(drawAvatar);
        }
        else {
            holder.finalImageView.setImageDrawable(context.getDrawable(R.drawable.avatar_1));
        }

        holder.finalView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Listener.onItemClick(position);
            }

        });
        holder.finalView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (Listener != null) {
                    Listener.onItemLongClick(position);
                }
                return true;
            }
        });

        holder.finalDeleteButtonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Listener != null) {
                    Listener.onItemDeleteClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return Values.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View finalView;
        public final TextView finalIdView;
        public final TextView finalNameSurnameView;
        public final ImageView finalImageView;
        public final ImageButton finalDeleteButtonView;
        public Contact finalItem;

        public ViewHolder(View view) {
            super(view);
            finalView = view;
            finalIdView = (TextView) view.findViewById(R.id.itemNumber);
            finalNameSurnameView = (TextView) view.findViewById(R.id.textViewContactNameAndSurname);
            finalImageView = view.findViewById(R.id.imageViewContactAvatar);
            finalDeleteButtonView = view.findViewById(R.id.imageButtonContactDelete);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + finalNameSurnameView.getText() + "'";
        }
    }
}